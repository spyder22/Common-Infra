package com.example.authenticationapi.controller;

import com.example.authenticationapi.payloads.requests.RegisterRequest;
import com.example.authenticationapi.service.UserDetailsServices.MyUserDetailService;
import com.example.authenticationapi.service.impl.AppsServiceImpl;
import com.example.authenticationapi.service.impl.CustomerServiceImpl;
import com.example.authenticationapi.service.impl.OriginServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.*;

class AuthenticationControllerTest {
//    @Autowired
    AuthenticationController authenticationController=new AuthenticationController();
//    @Autowired
    private MyUserDetailService myUserDetailService;


//    @Autowired
    private OriginServiceImpl originServiceImpl=new OriginServiceImpl();

//    @Autowired
    private CustomerServiceImpl customerServiceImpl=new CustomerServiceImpl();

//    @Autowired
    private AppsServiceImpl appsServiceImpl=new AppsServiceImpl();

    @Test
    void login() {
    }

    @Test
    void sendTimeStamp() {
    }

    @Test
    void logout() {
    }

    @Test
    void checkRegisterLowerBound() {

        RegisterRequest registerRequest=new RegisterRequest();
        registerRequest.setPassword("1234");
        registerRequest.setUserEmail("puchi@gmail.com");

        registerRequest.setAppId("1");

        assertNotNull(authenticationController.register(registerRequest));
//        assertEquals("register response",c.register(registerRequest),"success");



    }

    @Test
    void updateInterest() {
    }

    @Test
    void getInterestByMail() {
    }

    @Test
    void isRegisteredOnAppId() {
    }

    @Test
    void getRegisteredAppsByUser() {
    }

    @Test
    void getUsersInterestByMail() {
    }

    @Test
    void getUserInterestByMail() {
    }

    @Test
    void getUserProfile() {
    }

    @Test
    void getDeviceIds() {
    }

    @Test
    void getDeviceIdsFromEmails() {
    }
}