package com.example.authenticationapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthenticationapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthenticationapiApplication.class, args);
	}

}
